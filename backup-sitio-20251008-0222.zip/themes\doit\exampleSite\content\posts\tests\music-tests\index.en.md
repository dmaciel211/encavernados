---
title: "Music Tests"
date: 2021-04-16T14:47:54+01:00
lastmod: 2021-04-16T14:47:54+01:00
draft: true
description: "Music Tests"
categories: [Tests]
authors: [PCloud]
hiddenFromHomePage: true
hiddenFromSearch: true
---

<!--more-->

{{< music url="/music/Wavelength.mp3" name=Wavelength artist=oldmanyoung cover="/images/Wavelength.webp" >}}

---

{{< music auto="https://music.163.com/#/playlist?id=60198" >}}

---

{{< music server="netease" type="song" id="1868553" >}}