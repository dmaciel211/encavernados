module.exports = window.twemoji;
