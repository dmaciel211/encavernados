---
title: "¡Gracias!"
url: "/contacto/gracias/"
---
<html lang="es">
<section class="contacto">
  <h1>¡Gracias por escribirnos!</h1>
  <p>Recibimos tu mensaje y te vamos a responder a la brevedad.</p>
  <p><a href="/">Volver al inicio</a></p>
</section>
