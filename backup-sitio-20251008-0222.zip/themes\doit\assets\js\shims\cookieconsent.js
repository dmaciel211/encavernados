module.exports = window.cookieconsent;
