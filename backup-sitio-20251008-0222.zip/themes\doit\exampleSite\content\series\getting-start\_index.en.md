---
title: Getting start with DoIt
introduction: This series of articles helps you build your own blog with DoIt theme from scratch.
---
