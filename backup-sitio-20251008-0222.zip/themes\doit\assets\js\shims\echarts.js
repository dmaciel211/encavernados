module.exports = window.echarts;
