module.exports = window.Waline;
