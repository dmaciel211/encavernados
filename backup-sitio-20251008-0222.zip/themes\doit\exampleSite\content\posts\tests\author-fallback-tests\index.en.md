---
title: "Author Fallback Tests"
date: 2021-06-07T20:35:12+01:00
lastmod: 2021-06-07T20:35:12+01:00
draft: true
description: "Author Fallback Tests"
categories: [Tests]
hiddenFromHomePage: true
hiddenFromSearch: true
---

<!--more-->

When the `authors` front matter is not set, DoIt should fallback to the `author` option set in `config.toml` automatically.

[PCloud](https://github.com/HEIGE-PCloud)