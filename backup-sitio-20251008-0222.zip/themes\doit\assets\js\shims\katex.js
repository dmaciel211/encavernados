module.exports = window.renderMathInElement;
