---
title: "Friend Shortcode Tests"
subtitle: ""
date: 2021-04-29T13:41:31+01:00
lastmod: 2021-04-29T13:41:31+01:00
draft: true
description: "Friend Shortcode Tests"
categories: [Tests]
authors: [PCloud]
hiddenFromHomePage: true
hiddenFromSearch: true
---

<!--more-->

{{< friend name="PCloud" url="https://github.com/HEIGE-PCloud/" avatar="https://avatars.githubusercontent.com/u/52968553?v=4" bio="This is PCloud~💤" >}}

{{< friend name="PCloud" url="https://github.com/HEIGE-PCloud/" avatar="https://avatars.githubusercontent.com/u/52968553?v=4" bio="This is PCloud as well~" >}}

{{< friend name="" url="" avatar="" bio="" >}}

{{< friend "PCloud" "https://github.com/HEIGE-PCloud/" "https://avatars.githubusercontent.com/u/52968553?v=4" "Awwwwww, toooooooo many PCloud🤔" >}}

{{< friend "this_is_a_long_long_long_long_name" "https://github.com/HEIGE-PCloud/" "https://avatars.githubusercontent.com/u/52968553?v=4" "this_is_a_long_long_long_long_long_long_long_bio" >}}
