module.exports = window.APlayer;
