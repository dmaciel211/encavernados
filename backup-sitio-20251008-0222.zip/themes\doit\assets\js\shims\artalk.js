module.exports = window.Artalk;
