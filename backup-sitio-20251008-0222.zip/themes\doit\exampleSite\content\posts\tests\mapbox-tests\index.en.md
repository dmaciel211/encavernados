---
title: "Mapbox Tests"
date: 2021-04-16T14:45:40+01:00
lastmod: 2021-04-16T14:45:40+01:00
draft: true
description: "Mapbox Tests"
categories: [Tests]
authors: [PCloud]
hiddenFromHomePage: true
hiddenFromSearch: true
---

<!--more-->
{{< mapbox lng=121.485 lat=31.233 zoom=12 >}}

{{< mapbox -122.252 37.453 10 false "mapbox://styles/mapbox/navigation-preview-day-v4" "mapbox://styles/mapbox/navigation-preview-night-v4" >}}
