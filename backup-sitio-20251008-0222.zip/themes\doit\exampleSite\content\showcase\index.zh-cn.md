---
title: "作品"
date: 2021-11-01T20:08:29+08:00
draft: false

---

{{< showcase "主题文档 - 基本概念" "探索 Hugo - DoIt 主题的全部内容和背后的核心概念" "/theme-documentation-basics/featured-image.webp" "/zh-cn/theme-documentation-basics/" >}}

{{< showcase "主题文档 - 内容" "了解如何在 DoIt 主题中快速, 直观地创建和组织内容" "/theme-documentation-content/featured-image.webp" "/zh-cn/theme-documentation-content/" >}}

{{< showcase "主题文档 - 扩展 Shortcodes" "DoIt 主题在 Hugo 内置的 shortcode 的基础上提供多个扩展的 shortcode" "/theme-documentation-extended-shortcodes/featured-image.webp" "/zh-cn/theme-documentation-extended-shortcodes/" >}}
