# Security Policy

Only the latest commit on the `main` branch is supported. Fixes will not be backported to older versions. If you are using an older version, please update to the latest version promptly.

If you want to report a vulnerability, create a new issue at https://github.com/HEIGE-PCloud/DoIt/issues. Any vulnerabilities will be fixed as soon as possible.
