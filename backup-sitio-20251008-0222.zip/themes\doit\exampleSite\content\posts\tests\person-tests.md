---
title: "Person Tests"
date: 2024-05-11T17:54:33+01:00
lastmod: 2024-05-11T17:54:33+01:00
draft: true
description: "Person Shortcode Tests"
categories: [Tests]
hiddenFromHomePage: true
hiddenFromSearch: true
---

<!--more-->

This is a person with picture {{< person url="https://evgenykuznetsov.org" name="Evgeny Kuznetsov" nick="nekr0z" text="author of this shortcode" picture="https://evgenykuznetsov.org/img/avatar.jpg" >}}.


New paragraph {{< person "https://dillonzq.com/" Dillon "author of the LoveIt theme" >}}.
